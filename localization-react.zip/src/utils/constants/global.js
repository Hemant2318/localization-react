export const userType = [{ value: "beautician" }, { value: "client" }];

export const commonFilter = [
  { value: "All", id: "" },
  { value: "Active", id: 1 },
  { value: "Inactive", id: 0 },
];

export const genderlist = [
  { value: "Male", id: "Male" },
  { value: "Female", id: "Female" },
  // { value: "Other", id: "Other" },
];

export const appoitmentStatus = [
  { value: "Upcoming", id: 1 },
  { value: "Completed", id: 2 },
  { value: "Cancelled", id: 3 },
  { value: "No-show", id: 4 },
];

export const sendToList = [
  { value: "Beauticians", id: "Beautician" },
  // { value: "E-commerce", id: "E-commerce" },
  { value: "Clients", id: "Client" },
  // { value: "All", id: "All" },
];
