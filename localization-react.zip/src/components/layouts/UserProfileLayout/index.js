export { default } from "./UserProfileLayout";
