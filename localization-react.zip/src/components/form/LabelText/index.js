export { default } from "./LabelText";
