export { default } from "./PostInput";
